# Limine Boot Protocol

This repository contains the primary documentation and C/C++ header for the
Limine Boot Protocol.
