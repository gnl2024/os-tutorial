#ifndef LIB__TRACE_H__
#define LIB__TRACE_H__

#include <stddef.h>

void print_stacktrace(size_t *base_ptr);

#endif
