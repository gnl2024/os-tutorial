#ifndef LIBC_COMPAT__STDLIB_H__
#define LIBC_COMPAT__STDLIB_H__

unsigned long strtoul(const char *str, char **end, int base);

#endif
